let selecting = false;

chrome.runtime.onMessage.addListener((message) => {
  if (message.type === "start_selection") {
    selecting = true;
    document.body.style.cursor = "crosshair";
    document.addEventListener("mouseover", highlight);
    document.addEventListener("click", selectElement);
  }
});

function highlight(e) {
  if (!selecting) return;
  e.target.style.outline = "2px dashed transparent";
  setTimeout(() => e.target.style.outline = "", 300);
}

function selectElement(e) {
  e.preventDefault();
  if (!selecting) return;
  selecting = false;
  document.body.style.cursor = "default";
  document.removeEventListener("mouseover", highlight);
  document.removeEventListener("click", selectElement);

  const block = e.target.closest(".que.multichoice") || e.target;
  const text = block.innerText;

  chrome.runtime.sendMessage({
    type: "send_to_gpt",
    content: text
  });


  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === "show_answer") {
      // Создание элемента для ответа
      const answerElement = document.createElement("div");
      answerElement.textContent = message.answer;
  
      // Устанавливаем стиль для отображения в правом нижнем углу
      answerElement.style.position = "fixed";
      answerElement.style.bottom = "20px";
      answerElement.style.right = "20px";
      answerElement.style.padding = "10px";
      answerElement.style.backgroundColor = "rgba(255, 255, 255, 0.7)";  // Прозрачный белый фон (не полностью прозрачный)
      answerElement.style.color = "#808080"; 
      answerElement.style.borderRadius = "5px";
      answerElement.style.zIndex = "9999";
      answerElement.style.cursor = "pointer";
      answerElement.style.fontSize = "14px";
      answerElement.style.maxWidth = "250px";  // Ограничиваем ширину
      answerElement.style.wordWrap = "break-word";  // Текст будет переноситься на новую строку, если он слишком длинный
  
      // Ограничиваем длину текста
      if (message.answer.length > 100) {
        answerElement.textContent = message.answer.slice(0, 100) + "...";  // Ограничиваем длину до 100 символов
      }
  
      // Добавляем созданный элемент на страницу
      document.body.appendChild(answerElement);
  
      // Убираем ответ при клике
      answerElement.addEventListener("click", () => {
        answerElement.remove();
      });
  
      // Убираем ответ через 3 секунды
      setTimeout(() => {
        answerElement.remove();
      }, 1500);
    }
  });
  
} 