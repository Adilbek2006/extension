chrome.commands.onCommand.addListener((command) => {
  if (command === "activate-selection") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      chrome.tabs.sendMessage(tabs[0].id, { type: "start_selection" });
    });
  }
});

chrome.runtime.onMessage.addListener(async (message, sender) => {
  if (message.type === "send_to_gpt") {
    const apiKey = "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";
    const prompt = "Вопрос с вариантами ответа:\n" + message.content + 
    "\n\nОтветь только буквой правильного варианта (например: a). Без пояснений.Отвечай максимально правильно";  

    try {
      let response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${apiKey}`
        },
        body: JSON.stringify({
          model: "gpt-4o-mini",
          messages: [{ role: "user", content: prompt }],
          temperature: 0.7
        })
      });

      if (!response.ok) {
        throw new Error(`Ошибка от API: ${response.statusText}`);
      }

      const data = await response.json();
      console.log("Ответ от GPT:", JSON.stringify(data, null, 2)); 

      let answer = "Пустой ответ от модели";
      if (data && data.choices && data.choices.length > 0) {
        answer = data.choices[0].message?.content?.trim() || "Пустой ответ от модели";
      }

      chrome.tabs.sendMessage(sender.tab.id, {
        type: "show_answer",
        answer: answer
      });

    } catch (err) {
      console.error("Ошибка при обращении к GPT:", err);
      chrome.tabs.sendMessage(sender.tab.id, {
        type: "show_answer",
        answer: "Ошибка при обращении к GPT: " + err.message
      });
    }
  }
});

