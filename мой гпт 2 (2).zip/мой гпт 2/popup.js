chrome.storage.local.get("gpt_answer", ({ gpt_answer }) => {
    document.getElementById("answer").innerText = gpt_answer || "Нет данных";
  });
const connectBtn = document.getElementById("connectBtn");
const statusText = document.getElementById("statusText");
const statusDot = document.getElementById("statusDot");

let connected = false;

connectBtn.addEventListener("click", () => {
  connected = !connected;

  if (connected) {
    statusText.textContent = "Connected";
    statusDot.style.background = "green";
    connectBtn.textContent = "Disconect";
  } else {
    statusText.textContent = "Disabled";
    statusDot.style.background = "red";
    connectBtn.textContent = "Connect";
  }
});